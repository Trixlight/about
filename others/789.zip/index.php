﻿<!DOCTYPE html>

<html lang="ru-RU">

<head>

	<title>Solar Wind</title>

	<meta charset="utf-8">

	<meta name="keywords" content="solar, wind, guild, community, guild, wars">

	<meta name="author" content="<?php	$lang = isset($_GET["lang"])? $_GET["lang"]: "ru"; $array = parse_ini_file("theme/".$lang.".ini"); echo $array["name"]; ?>">

	<meta name="description" content="<?php	$lang = isset($_GET["lang"])? $_GET["lang"]: "ru"; $array = parse_ini_file("theme/".$lang.".ini"); echo $array["description"]; ?>">

	<link href="/theme/style.css" rel="stylesheet" type="text/css">

	<link href='http://fonts.googleapis.com/css?family=Cuprum:400,700,400italic,700italic&amp;subset=latin,cyrillic' rel='stylesheet' type='text/css'>

</head>

<body>
	<div id="page">

	<div class="wrap"></div>

	 <div class="lang">

	 	<a href="/?lang=ru">RU</a> |

		<a href="/?lang=en">EN</a>

	</div>
		<article>

			<header>

				<figure>

					<img class="logo" src="/theme/images/logo.png" alt="logo">

				</figure>
	
				<h1>

					<?php
 $lang = isset($_GET["lang"])? $_GET["lang"]: "ru";
						$array = parse_ini_file("theme/".$lang.".ini");

  						echo $array["name"];
 ?>

				</h1>

				<h3>"Solar Wing"</h3>

			</header>

				<p>

					<?php $lang = isset($_GET["lang"])? $_GET["lang"]: "ru";
						$array = parse_ini_file("theme/".$lang.".ini");

  						echo $array["description"];

  					?>

  					<br>

					<?php
 $lang = isset($_GET["lang"])? $_GET["lang"]: "ru";

						$array = parse_ini_file("theme/".$lang.".ini");

  						echo $array["tech.works"];

					?>

				</p>

				<div class="social">

					<a href="http://vk.com/sineden" target="_blank"><img src="/theme/images/vk-128.png" alt="Vkontakte"></a>

					<a href="http://youtube.com/trixlight" target="_blank"><img src="/theme/images/youtube-128.png" alt="YouTube"></a>

					<a href="http://ru.twitch.tv/sineden" target="_blank"><img src="/theme/images/twitch-128.png" alt="Twitch"></a>

					<a href="http://steamcommunity.com/id/sineden" target="_blank"><img src="/theme/images/steam-128.png" alt="Steam"></a>

					<a href="http://twitter.com/trixlight" target="_blank"><img src="/theme/images/twitter-128.png" alt="Twitter"></a>

				</div>

				<div class="warp"></div>

				<a rel="nofollow" class="twitter-timeline" href="https://twitter.com/trixlight" data-widget-id="433635166578176000">Твиты пользователя @trixlight</a>

				<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

		</article>

	<div class="wrap"></div>

	</div><!-- #page-->

</body>

</html>